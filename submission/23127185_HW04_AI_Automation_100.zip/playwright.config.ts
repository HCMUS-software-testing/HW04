import { defineConfig, devices } from '@playwright/test';

function getUTC7Timestamp(): string {
  const now = new Date();
  const utc7Date = new Date(now.getTime() + (now.getTimezoneOffset() + 420) * 60000);
  const pad = (n: number) => String(n).padStart(2, '0');
  const pad3 = (n: number) => String(n).padStart(3, '0');
  return `${utc7Date.getFullYear()}-${pad(utc7Date.getMonth() + 1)}-${pad(utc7Date.getDate())}T${pad(utc7Date.getHours())}:${pad(utc7Date.getMinutes())}:${pad(utc7Date.getSeconds())}.${pad3(utc7Date.getMilliseconds())}+07:00`;
}

process.env.RUN_TIMESTAMP = process.env.RUN_TIMESTAMP || getUTC7Timestamp();

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// import dotenv from 'dotenv';
// import path from 'path';
// dotenv.config({ path: path.resolve(__dirname, '.env') });

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  testDir: './tests',
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('')`. */
    baseURL: process.env.BASE_URL || 'http://localhost:5173',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
  },
  reporter: [
    ['html', { outputFolder: 'playwright-report', open: 'never' }]
  ],
  metadata: {
    'Run by': process.env.STUDENT_ID || '23127185',
    'Timestamp': process.env.RUN_TIMESTAMP,
  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    {
      name: 'coccoc',
      use: {
        ...devices['Desktop Chrome'],
        executablePath: '/usr/bin/coccoc-browser',
      },
    },

    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Coc Coc',
    //   use: { ...devices['Desktop Coc Coc'], channel: 'msCoc Coc' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
