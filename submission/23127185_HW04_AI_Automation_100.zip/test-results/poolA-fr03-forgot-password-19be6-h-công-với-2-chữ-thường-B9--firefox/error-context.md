# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: poolA-fr03-forgot-password.spec.ts >> FR-03: Forgot Password & Password Reset (Pool A) | Run by: 23127185 | Timestamp: 2026-08-22T16:07:47.542+07:00 >> TC10: Kiểm tra đặt lại mật khẩu thành công với 2 chữ thường (B9)
- Location: tests/poolA-fr03-forgot-password.spec.ts:14:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByPlaceholder(/xác nhận mật khẩu|confirm password/i).or(getByLabel(/xác nhận mật khẩu|confirm password/i))
Expected: visible
Timeout: 3000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 3000ms
  - waiting for getByPlaceholder(/xác nhận mật khẩu|confirm password/i).or(getByLabel(/xác nhận mật khẩu|confirm password/i))

```

```yaml
- banner:
  - link "EShop":
    - /url: /
  - navigation:
    - link "Giỏ hàng":
      - /url: /cart
    - link "Đăng nhập":
      - /url: /login
    - link "Đăng ký":
      - /url: /register
- main:
  - heading "Quên Mật Khẩu" [level=2]
  - text: "Mã OTP của bạn là: 1453 Mã OTP (4 số)"
  - textbox: "123456"
  - text: Mật khẩu mới
  - textbox: AAAAAAAAaa1!
  - button "Đặt lại mật khẩu"
  - button "← Quay lại"
- contentinfo: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import testData from './data/poolA-fr03-forgot-password.json';
  3   | 
  4   | const studentId = process.env.STUDENT_ID || '23127185';
  5   | const timestamp = process.env.RUN_TIMESTAMP || new Date().toISOString();
  6   | 
  7   | test.describe(`FR-03: Forgot Password & Password Reset (Pool A) | Run by: ${studentId} | Timestamp: ${timestamp}`, () => {
  8   |   test.beforeEach(async ({ page }) => {
  9   |     // Navigate to forgot password page
  10  |     await page.goto('/forgot-password');
  11  |   });
  12  | 
  13  |   for (const tc of testData) {
  14  |     test(`${tc.id}: ${tc.title}`, async ({ page }) => {
  15  |       // Set up dialog listener to capture alerts
  16  |       let dialogMessage = '';
  17  |       page.on('dialog', async (dialog) => {
  18  |         dialogMessage = dialog.message();
  19  |         await dialog.dismiss();
  20  |       });
  21  | 
  22  |       if (tc.step === 1) {
  23  |         // Step 1: Request OTP
  24  |         const emailInput = page.locator('input[type="text"]').first();
  25  | 
  26  |         if (tc.email !== '') {
  27  |           await emailInput.fill(tc.email);
  28  |         } else {
  29  |           await emailInput.clear();
  30  |         }
  31  | 
  32  |         const submitBtn = page.getByRole('button', { name: /lấy mã otp|yêu cầu otp|gửi|submit/i });
  33  |         await submitBtn.click();
  34  | 
  35  |         // Assertion Patterns used:
  36  |         if (tc.assertionPattern === 'validationMessage' || tc.id === 'TC3') {
  37  |           // 1. Form / Control State Assertion (HTML5 Validation or Input State)
  38  |           const validationMessage = await emailInput.evaluate((el: HTMLInputElement) => el.validationMessage);
  39  |           expect(validationMessage).toBeTruthy();
  40  |         } else if (tc.assertionPattern === 'visibleText') {
  41  |           // 2. Visible Text / Notification Message Assertion (Dialog or Page Alert or OTP banner)
  42  |           if (dialogMessage) {
  43  |             expect(dialogMessage).toMatch(/lỗi|mã otp|không hợp lệ|chưa được đăng ký/i);
  44  |           } else {
  45  |             const messageElement = page.getByText(new RegExp(tc.expectedMessage, 'i'))
  46  |               .or(page.locator('div:has-text("Mã OTP của bạn là:")'))
  47  |               .or(page.locator('.alert, .message, .error, .toast')).first();
  48  | 
  49  |             await expect(messageElement).toBeVisible();
  50  | 
  51  |             // TC1: Bổ sung kiểm tra OTP phải đủ 6 chữ số (BUG-002)
  52  |             if (tc.id === 'TC1') {
  53  |               const otpBanner = page.locator('div:has-text("Mã OTP của bạn là:")').first();
  54  |               const bannerText = await otpBanner.innerText();
  55  |               const otpMatch = bannerText.match(/(\d+)/);
  56  |               expect(otpMatch, 'OTP phải được hiển thị dạng số').toBeTruthy();
  57  |               expect(otpMatch![1].length, 'OTP phải có đúng 6 chữ số').toBe(6);
  58  |             }
  59  |           }
  60  |         }
  61  |       } else if (tc.step === 2) {
  62  |         // Step 2: Reset Password with OTP
  63  |         const emailInput = page.locator('input[type="text"]').first();
  64  |         if (await emailInput.isVisible()) {
  65  |           await emailInput.fill(tc.email);
  66  |           const requestOtpBtn = page.getByRole('button', { name: /lấy mã otp|yêu cầu otp|gửi|submit/i });
  67  |           await requestOtpBtn.click();
  68  |         }
  69  | 
  70  |         // Extract reset token from Step 2 message if available
  71  |         let tokenToUse = tc.otp;
  72  |         const messageBox = page.locator('div:has-text("Mã OTP của bạn là:")').first();
  73  |         if (await messageBox.isVisible()) {
  74  |           const msgText = await messageBox.innerText();
  75  |           const match = msgText.match(/Mã OTP của bạn là:\s*(\w+)/);
  76  |           if (match && match[1]) {
  77  |             tokenToUse = match[1];
  78  |           }
  79  |         }
  80  | 
  81  |         // Fill OTP
  82  |         const otpInput = page.locator('input[type="text"]').first();
  83  |         await otpInput.fill(tokenToUse);
  84  | 
  85  |         // Fill New Password
  86  |         const newPasswordInput = page.locator('input[type="password"]').first();
  87  |         await newPasswordInput.fill(tc.newPassword);
  88  | 
  89  |         // Fill Confirm Password if field exists
  90  |         const confirmPasswordInput = page.getByPlaceholder(/xác nhận mật khẩu|confirm password/i).or(page.getByLabel(/xác nhận mật khẩu|confirm password/i));
  91  |         // Assert trường Xác nhận mật khẩu phải tồn tại (SUT BUG-001: thiếu trường này)
> 92  |         await expect(confirmPasswordInput).toBeVisible({ timeout: 3000 });
      |                                            ^ Error: expect(locator).toBeVisible() failed
  93  |         await confirmPasswordInput.fill(tc.confirmPassword);
  94  | 
  95  |         const resetBtn = page.getByRole('button', { name: /đặt lại mật khẩu|reset password|xác nhận/i });
  96  |         await resetBtn.click();
  97  | 
  98  |         // Assertion Pattern used:
  99  |         if (tc.assertionPattern === 'urlState') {
  100 |           // Expect navigation to login page on successful reset
  101 |           await expect(page).toHaveURL(/login|reset-success/i, { timeout: 3000 });
  102 |         } else {
  103 |           // Expect visible success message
  104 |           const messageElement = page.getByText(new RegExp(tc.expectedMessage, 'i')).first();
  105 |           await expect(messageElement).toBeVisible({ timeout: 3000 });
  106 |         }
  107 |       }
  108 |     });
  109 |   }
  110 | });
  111 | 
```